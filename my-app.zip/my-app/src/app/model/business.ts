export default class Business {
    _id: string;
    person_name: string;
    business_name: string;
    business_gst_number: number;
}