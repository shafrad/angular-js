import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gst-add',
  templateUrl: './gst-add.component.html',
  styleUrls: ['./gst-add.component.scss']
})
export class GstAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
